export default function Loading() {
  return (
    <div className='text-center'>
      <img src="imgs/loader.gif" alt="Loading" style={{ height: "200px", width: "200px" }} />
    </div>
  )
}
